'''
Experimental Setup:
- OS: Ubuntu 20.04.6 LTS
- Hardware:
  - CPU: Intel Xeon Gold 6248R
  - GPU: 2 × NVIDIA GeForce RTX 3090 (24GB each)
  - RAM: 256GB
- Software:
  - Python 3.8
  - PyTorch with CUDA

Note: Results may vary if run on different hardware or software configurations. For any issues, please contact: guowei123@email.swu.edu.cn
'''

from util_funs import *
from CAGL_SGA import CAGL_SGA


if __name__ == "__main__":
    data_path = "YaleA_mtv.mat"
    X, gt = load_data_from_mat(data_path)
    k = 4  # m=k*c
    beta = 0.001
    gamma = 0.05
    Z_star, gt_tensor, Clus_num = CAGL_SGA(X, gt, k, beta, gamma)
    result = perform_clustering(Z_star, gt_tensor, Clus_num)
    print('ACC = {:.4f} NMI = {:.4f} PUR={:.4f} fscore = {:.4f}, precision = {:.4f} recall = {:.4f} ari={:.4f}'.format(result[0], result[1], result[2], result[3], result[4], result[5], result[6]))