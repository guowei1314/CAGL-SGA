import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
import torch
from EvaluateMetrices import *
from scipy.io import loadmat

def EProjSimplex_new(v, k=1):
    n = v.numel()
    v0 = v - torch.mean(v) + k / n
    vmin = torch.min(v0)

    if vmin < 0:
        lambda_m = torch.tensor(0.0, device=v.device, dtype=v.dtype)
        eps = torch.finfo(v.dtype).eps

        for _ in range(100):
            v1 = v0 - lambda_m
            posidx = v1 > 0
            npos = torch.sum(posidx)
            g = -npos.float()
            f = torch.sum(v1[posidx]) - k

            if abs(f) < 1e-10:
                break

            # 避免除零
            if g == 0:
                break
            lambda_m = lambda_m - f / g

        x = torch.clamp(v1, min=0)
    else:
        x = v0
    return x

def solve_hungarian(A):
    """
    使用匈牙利算法解决分配问题
    """
    from scipy.optimize import linear_sum_assignment
    device = A.device
    n = A.size(0)
    C = -A.cpu().numpy()
    row_ind, col_ind = linear_sum_assignment(C)
    P = torch.zeros(n, n, device=device)
    P[row_ind, col_ind] = 1
    return P

def L2_distance_1(a, b):
    """
    计算两个矩阵之间的平方欧几里得距离
    ||A-B||^2 = ||A||^2 + ||B||^2 - 2*A'*B

    Parameters:
        a, b: 两个矩阵，每列是一个数据点 (torch.Tensor)

    Returns:
        d: 距离矩阵 (torch.Tensor)
    """
    # 处理一维情况
    if a.dim() == 1:
        a = a.unsqueeze(0)
    if b.dim() == 1:
        b = b.unsqueeze(0)

    if a.size(0) == 1:
        a = torch.cat([a, torch.zeros(1, a.size(1), device=a.device)], dim=0)
        b = torch.cat([b, torch.zeros(1, b.size(1), device=b.device)], dim=0)

    # 计算平方范数
    aa = torch.sum(a * a, dim=0)  # shape: (n_a,)
    bb = torch.sum(b * b, dim=0)  # shape: (n_b,)

    # 计算点积
    ab = torch.mm(a.t(), b)  # shape: (n_a, n_b)

    # 使用广播机制计算距离矩阵
    d = aa.unsqueeze(1) + bb.unsqueeze(0) - 2 * ab

    # 确保结果为实数和非负
    d = d.real
    d = torch.clamp(d, min=0)

    return d

def NormalizeFea(fea, inplace=False):
    """Normalize features using PyTorch only"""
    if not inplace:
        fea = fea.clone()

    # PyTorch 实现 L2 归一化
    norms = torch.norm(fea, p=2, dim=0, keepdim=True)
    norms = torch.where(norms == 0, torch.ones_like(norms), norms)  # 避免除零
    fea = fea / norms

    return fea




def load_data_from_mat(file_path):

    # 加载MAT文件
    mat_data = loadmat(file_path)

    # 提取X和gt变量
    mat_X = mat_data['X']  # 假设X是cell数组，1行V列
    mat_gt = mat_data['gt']  # 真实标签列向量
    # 将MATLAB cell转换为Python列表
    X = []
    for i in range(mat_X.shape[1]):  # 遍历列
        # 从MATLAB cell中提取矩阵并转换为numpy数组
        view_data = mat_X[0, i]
        view_data = view_data.T  ##是否转置
        # 转换数据类型为PyTorch支持的格式
        if view_data.dtype == np.uint16:
            view_data = view_data.astype(np.float32)  # 转换为float32
        elif view_data.dtype == np.uint8:
            view_data = view_data.astype(np.float32)
        # 可以添加其他数据类型的转换

        X.append(view_data)

    # 确保gt是1维数组
    gt = mat_gt.flatten()

    return X, gt

def perform_clustering(Z_star, gt, Clus_num):
    U, _, _ = torch.svd(Z_star.t())
    UU = U[:, :Clus_num]

    result1 = []
    for i in range(10):
        kmeans = KMeans(n_clusters=Clus_num, n_init=20)
        pre_labels = kmeans.fit_predict(UU.cpu().real.numpy())
        result1.append(cluster(gt.cpu().numpy(), pre_labels))
    return np.mean(result1, axis=0)