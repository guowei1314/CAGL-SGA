'''
Experimental Setup:
- OS: Ubuntu 20.04.6 LTS
- Hardware:
  - CPU: Intel Xeon Gold 6248R
  - GPU: 2 × NVIDIA GeForce RTX 3090 (24GB each)
  - RAM: 256GB
- Software:
  - Python 3.8
  - PyTorch with CUDA

Note: Results may vary if run on different hardware or software configurations. For any issues, please contact: guowei123@email.swu.edu.cn
'''
import torch
import numpy as np
from util_funs import *



def CAGL_SGA(X, gt, k, beta, gamma):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 确保 gt 是 PyTorch 张量
    if isinstance(gt, np.ndarray):
        gt = torch.from_numpy(gt).to(device)

    # 确保 X 中的每个视图都是 PyTorch 张量
    X_torch = []
    for i in range(len(X)):
        if isinstance(X[i], np.ndarray):
            X_torch.append(torch.from_numpy(X[i]).float().to(device))
        else:
            X_torch.append(X[i].float().to(device))
    X = X_torch

    theta = 1
    epson = 1e-6
    Clus_num = len(torch.unique(gt))
    V = len(X)
    N = X[0].shape[1]
    m = Clus_num * k

    # Initialize parameters
    lambda_ = torch.ones(V, device=device) / V
    alpha = torch.ones(V, device=device) / V
    # Normalize features - 确保返回的是 PyTorch 张量
    X_norm = []
    for i in range(V):
        normalized_feat = NormalizeFea(X[i].clone())
        X_norm.append(normalized_feat)
    X = X_norm

    # Initialize variables
    A = [torch.zeros(X[i].shape[0], m, device=device) for i in range(V)]
    Z = [torch.eye(m, N, device=device) for i in range(V)]
    G = [torch.zeros(m, m, device=device) for i in range(V)]
    S = [torch.zeros(m, m, device=device) for i in range(V)]
    Y = [torch.zeros(m, m, device=device) for i in range(V)]
    T = [torch.zeros(m, m, device=device) for i in range(V)]
    P = [torch.eye(m, m, device=device) for i in range(V)]
    Z_star = torch.zeros(m, N, device=device)

    mu = 0.01
    mu_max = 10e9
    eta = 1.5
    converge_SG = []
    Isconverg = False
    iter_count = 1

    while not Isconverg:
        # Update P[i]
        for i in range(V):
            if i != 0:
                C1 = beta * T[i] @ G[i].t() + gamma / 2 * Z_star @ Z_star.t() @ T[i] + theta * Z_star @ Z[i].t()
                P[i] = solve_hungarian(C1)
        # print(torch.trace(P[2]).sum())
        # Update A[i]
        for i in range(V):
            M1 = X[i] @ Z[i].t()  # 现在 X[i] 和 Z[i] 都是 PyTorch 张量
            U, _, Vh = torch.svd(M1)
            A[i] = U @ Vh.t()

        # Update Z[i]
        for i in range(V):
            W = S[i]
            L = torch.diag(torch.sum(W, dim=1)) - W
            inv_term = torch.linalg.pinv((1 / alpha[i]) * torch.eye(m, device=device) +
                                         theta * torch.eye(m, device=device) +
                                         2 * lambda_[i] * L)
            Z[i] = inv_term @ ((1 / alpha[i]) * A[i].t() @ X[i] + theta * P[i].t() @ Z_star)

        # Update G[i]
        for i in range(V):
            G[i] = (2 * beta * P[i].t() @ T[i] + mu * S[i] + Y[i]) / (2 * beta + mu)

        # Update T[i]
        for i in range(V):
            T[i] = P[i] @ G[i] + gamma / (2 * beta) * Z_star @ Z_star.t() @ P[i]

        # Update Z_star
        A_sum = torch.zeros(m, m, device=device)
        B_sum = torch.zeros(m, N, device=device)
        for i in range(V):
            A_sum += 2 * theta * torch.eye(m, device=device) - gamma * (P[i] @ T[i].t() + T[i] @ P[i].t())
            B_sum += 2 * theta * P[i] @ Z[i]
        # Z_star = torch.inverse(A_sum) @ B_sum
        try:
            Z_star = torch.linalg.pinv(A_sum) @ B_sum
            # 如果结果出现 NaN/Inf，就改用 Tikhonov 正则化
            if torch.isnan(Z_star).any() or torch.isinf(Z_star).any():
                reg = 1e-6
                I = torch.eye(A_sum.shape[-1], device=A_sum.device, dtype=A_sum.dtype)
                Z_star = torch.linalg.solve(A_sum.T @ A_sum + reg * I, A_sum.T @ B_sum)

        except torch._C._LinAlgError:
            lambda_reg = 1e-6  # 正则化系数
            I = torch.eye(A_sum.shape[0], device=A_sum.device)
            Z_star = torch.linalg.pinv(A_sum + lambda_reg * I) @ B_sum

        # if np.isnan(Z_star).any():
        #     print("矩阵Z_star中包含NaN值:")

        # Update S[i]
        for i in range(V):
            ed = lambda_[i] * L2_distance_1(Z[i].t(), Z[i].t())

            temp_A = torch.zeros(m, m, device=device)
            B = G[i] - Y[i] / mu

            for j in range(m):
                ad = (mu * B[j, :] - ed[j, :]) / mu

                temp_A[j, :] = EProjSimplex_new(ad)

            S[i] = temp_A

        # Update lambda[i]
        SUM = torch.zeros(m, m, device=device)
        distQ = torch.zeros(m, m, V, device=device)
        for i in range(V):
            distQ[:, :, i] = L2_distance_1(Z[i].t(), Z[i].t())
            SUM += distQ[:, :, i]

        for i in range(V):
            lambda_[i] = 0.5 / (torch.sqrt(torch.sum(distQ[:, :, i] * S[i])) + 1e-12)

        # update alpha[i]
        alpha_sum = 0
        alpha_v = []
        for i in range(V):
            alpha_val = torch.norm(X[i] - A[i] @ Z[i], p='fro')
            alpha_v.append(alpha_val)
            alpha_sum = alpha_sum + alpha_val
        for i in range(V):
            alpha[i] = alpha_v[i] / alpha_sum

        # Update Y
        for i in range(V):
            Y[i] = Y[i] + mu * (S[i] - G[i])

        # Check convergence
        max_SG = 0
        Isconverg = True

        for i in range(V):
            norm_SG = torch.norm(S[i] - G[i], p=float('inf'))
            if norm_SG > epson:
                Isconverg = False
                max_SG = max(max_SG, norm_SG.item())

        converge_SG.append(max_SG)
        # print(converge_SG)

        # Update mu
        mu = min(mu_max, mu * eta)
        iter_count += 1

        if iter_count == 100:
            Isconverg = True
    return Z_star, gt, Clus_num



#
# if __name__ == "__main__":
#     data_path = "YaleA_mtv.mat"
#     X, gt = load_data_from_mat(data_path)
#
#     k = 4  # m=k*c
#     beta = 0.001
#     gamma = 0.05
#
#     Z_star, gt_tensor, Clus_num = PC2AF_clustering(X, gt, k, beta, gamma)
#     result = perform_clustering(Z_star, gt_tensor, Clus_num)
#
#     # 打印结果
#     print('ACC = {:.4f} NMI = {:.4f} PUR={:.4f} fscore = {:.4f}, precision = {:.4f} recall = {:.4f} ari={:.4f}'.format(
#         result[0], result[1], result[2], result[3], result[4], result[5], result[6]))
